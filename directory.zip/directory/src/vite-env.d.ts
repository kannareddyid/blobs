/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_APP_TITLE: string;
  readonly clientId: string;
  readonly authority: string;
  readonly redirectUri: string;
  readonly graphApiMeEndpoint: string;
  readonly myportalApiGetMyRolesEndpoint: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
