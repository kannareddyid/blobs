// Just a Utility Library
type AccessTokenStore = {
  [key: string]: string | null;
};

const accessTokenStore: AccessTokenStore = {};

export const getStoreAccessToken = (apiName: string): string | null => {
  return accessTokenStore[apiName] || null;
};

export const setStoreAccessToken = (apiName: string, accessToken: string) => {
  accessTokenStore[apiName] = accessToken;
};

export const clearStoreToken = (apiName: string) => {
  accessTokenStore[apiName] = null;
};
