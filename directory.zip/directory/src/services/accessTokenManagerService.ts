import { isTokenExpired } from "../utils/tokenValidationHelper";
import { accessTokenAcquireService } from "./accessTokenAcquireService";
import {
  clearStoreToken,
  getStoreAccessToken,
  setStoreAccessToken,
} from "./accessTokenStoreService";
import { apiSilentRequestStore } from "./authService";

//AxiosInstances calls this method
export const getApiAccessToken = async (
  apiName: string
): Promise<string | null> => {
  const storedToken = getStoreAccessToken(apiName);

  //Returns stored API AccessToken if not expired otherwise it returns new token
  if (storedToken && !isTokenExpired(storedToken)) {
    return storedToken;
  }

  const silentRequest = apiSilentRequestStore[apiName];

  if (!silentRequest) {
    console.error(`No request configuration found for API: ${apiName}`);
    return null;
  }

  //Returns new API AccessToken, Gets AccessToken from IdP Server
  const newAcquiredToken = await accessTokenAcquireService(silentRequest);

  if (newAcquiredToken) {
    setStoreAccessToken(apiName, newAcquiredToken);
  }

  return newAcquiredToken;
};

export const clearApiAccessToken = (apiName: string) => {
  clearStoreToken(apiName);
};
