import {
  PublicClientApplication,
  RedirectRequest,
  SilentRequest,
} from "@azure/msal-browser";
import { msalConfig } from "../configs/authConfig";

//Global single MSAL instance that will reused everywhere
export const msalInstance = new PublicClientApplication(msalConfig);

// Add here scopes for id token to be used at MS Identity Platform endpoints.
export const loginRedirectRequest: RedirectRequest = {
  scopes: ["User.Read", "openid", "profile", "offline_access"], //works only for MyPortal API, Refer Page2 Component & also refer to github line 15 link
};

export const myportalApiSilentRequest: SilentRequest = {
  scopes: ["api://f9326158-59d4-468c-8e92-5ae67058d7b5/access_as_user"], //works only for MyPortal API, Refer Page2 Component & also refer to github line 15 link
};

export const graphApiSilentRequest: SilentRequest = {
  scopes: ["User.Read"], //works only for Graph API, Refer Page3 Component & also refer to github line 15 link
};


//Performance and Dynamic switch for API Auth Request Type
//Dictionary, Key(ApiName):Value(AuthRequestType), Acts like switch for multiple API to acquire access token for each API
//getApiAccessToken() uses this store
export const apiSilentRequestStore: { [key: string]: SilentRequest } = {
  graphApi: graphApiSilentRequest,
  myportalApi: myportalApiSilentRequest,
};


