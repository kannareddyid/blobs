// Just a Utility Library

import {
  InteractionRequiredAuthError,
  SilentRequest,
} from "@azure/msal-browser";
import { msalInstance } from "./authService";

export const accessTokenAcquireService = async (
  silentRequest: SilentRequest
): Promise<string | null> => {
  const accounts = msalInstance.getAllAccounts();
  const account = accounts[0];

  if (accounts.length === 0) return null;

  try {
    const response = await msalInstance.acquireTokenSilent({
      ...silentRequest,
      account,
    });
    return response.accessToken;
  } catch (error) {
    if (error instanceof InteractionRequiredAuthError) {
      try {
        const response = await msalInstance.acquireTokenPopup(silentRequest);
        return response.accessToken;
      } catch (popupError) {
        console.error(popupError);
        return null;
      }
    } else {
      console.error(error);
      return null;
    }
  }
};
