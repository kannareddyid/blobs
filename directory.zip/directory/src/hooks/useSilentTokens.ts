import { useState, useEffect } from "react";
import { useMsal, useAccount, useIsAuthenticated } from "@azure/msal-react";
import { AuthenticationResult, SilentRequest } from "@azure/msal-browser";

interface AuthTokens {
  accessToken: string | null;
  idToken: string | null;
  error: string | null;
}

//Not used anywhere
export const useSilentTokens = (silentRequest: SilentRequest): AuthTokens => {
  const { instance, accounts } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const account = useAccount(accounts[0] || {});
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [idToken, setIdToken] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isAuthenticated && account) {
      instance
        .acquireTokenSilent({
          ...silentRequest,
          account: account,
        })
        .then((response: AuthenticationResult) => {
          setAccessToken(response.accessToken);
          setIdToken(response.idToken);
        })
        .catch((error) => {
          console.error("Error acquiring token silently", error);
          setError("Failed to acquire access token");
        });
    }
  }, [isAuthenticated, account, instance, silentRequest]);

  return { accessToken, idToken, error };
};
