import { useState, useEffect } from "react";
import { useMsal, useAccount, useIsAuthenticated } from "@azure/msal-react";
import { AuthenticationResult } from "@azure/msal-browser";
import { loginRedirectRequest } from "../services/authService";

interface AuthTokens {
  accessToken: string | null;
  idToken: string | null;
  error: string | null;
}

export const useLoginTokens = (): AuthTokens => {
  const { instance, accounts } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const account = useAccount(accounts[0] || {});
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [idToken, setIdToken] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isAuthenticated && account) {
      instance
        .acquireTokenSilent({
          ...loginRedirectRequest,
          account: account,
        })
        .then((response: AuthenticationResult) => {
          setAccessToken(response.accessToken);
          setIdToken(response.idToken);
        })
        .catch((error) => {
          console.error("Error acquiring token silently", error);
          setError("Failed to acquire access token");
        });
    }
  }, [isAuthenticated, account, instance]);

  return { accessToken, idToken, error };
};
