import { Configuration } from "@azure/msal-browser";

// Config object to be passed to Msal on creation
export const msalConfig: Configuration = {
  auth: {
    clientId: import.meta.env.VITE_clientId,
    authority: import.meta.env.VITE_authority,
    redirectUri: import.meta.env.VITE_redirectUri,
    postLogoutRedirectUri: "/",
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  },
  system: {
    // loggerOptions: {
    //   loggerCallback: (level, message, containsPII) => {
    //     console.log(message);
    //   },
    //   logLevel: LogLevel.Info,
    // },
  },
};
