export const myportalApiConfig = {
  getMyRolesEndpoint: import.meta.env.VITE_myportalApiGetMyRolesEndpoint,
};
