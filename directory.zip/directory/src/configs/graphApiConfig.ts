export const graphApiConfig = {
  graphApiMeEndpoint: import.meta.env.VITE_graphApiMeEndpoint,
};
