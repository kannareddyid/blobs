import axios, {
  AxiosResponse,
  AxiosError,
  InternalAxiosRequestConfig,
} from "axios";
import { getApiAccessToken } from "../services/accessTokenManagerService";

// Create an Axios instance
export const myportalApiAxiosInstance = axios.create();

// Request Interceptor
myportalApiAxiosInstance.interceptors.request.use(
  async (config: InternalAxiosRequestConfig) => {
    // Modify the request config before sending it

    const accessToken: string | null = await getApiAccessToken("myportalApi");

    if (accessToken) {
      config.headers["Authorization"] = `Bearer ${accessToken}`;
    }

    return config;
  },
  (error: AxiosError) => {
    // Handle the request error
    return Promise.reject(error);
  }
);

// Response Interceptor
myportalApiAxiosInstance.interceptors.response.use(
  (response: AxiosResponse) => {
    // Any status code within the range of 2xx causes this function to trigger
    return response;
  },
  (error: AxiosError) => {
    // Handle the response error
    if (error.response?.status === 401) {
      // For example, handle unauthorized access
      // You could redirect to a login page or show a notification
    }
    return Promise.reject(error);
  }
);
