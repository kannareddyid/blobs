import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { App } from "./App.tsx";

import { EventType } from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { Page1 } from "./pages/Page1.tsx";
import { Page2 } from "./pages/Page2.tsx";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { PageNotFound } from "./pages/PageNotFound.tsx";
import { msalInstance } from "./services/authService.ts";
import { Page3 } from "./pages/Page3.tsx";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <PageNotFound />,
    children: [
      {
        path: "/",
        element: <Page1 />,
      },
      {
        path: "page1",
        element: <Page1 />,
      },
      {
        path: "page2",
        element: <Page2 />,
      },
      {
        path: "page3",
        element: <Page3 />,
      },
    ],
  },
]);

//Log sign-in account infomartion in console
msalInstance.addEventCallback((event) => {
  if (event.eventType === EventType.LOGIN_SUCCESS) {
    console.log(event); //logs MSAL Instance Data

    //msalInstance.setActiveAccount(event.payload.account);
  }
});

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <MsalProvider instance={msalInstance}>
      <RouterProvider router={router} />
    </MsalProvider>
  </React.StrictMode>
);
