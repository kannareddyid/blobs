import React, { useEffect } from "react";
import {
  useMsal,
  useIsAuthenticated,
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
} from "@azure/msal-react";
import { Navbar } from "./components/Navbar";
import { InteractionStatus } from "@azure/msal-browser";
import { Outlet } from "react-router-dom";
import { loginRedirectRequest } from "./services/authService";

export const App: React.FC = () => {
  const { instance, inProgress } = useMsal();
  const isAuthenticated = useIsAuthenticated();

  //const { login, error } = useMsalAuthentication(InteractionType.Redirect, loginRedirectRequest); //works

  useEffect(() => {
    const login = async () => {
      if (inProgress === InteractionStatus.None && !isAuthenticated) {
        await instance.loginRedirect(loginRedirectRequest);
      }
    };

    login();
  }, [isAuthenticated, instance, inProgress]);

  if (
    inProgress === InteractionStatus.Login ||
    inProgress === InteractionStatus.Startup
  ) {
    return <div>Login Page Loading...</div>;
  }

  return (
    <>
      <Navbar />
      <UnauthenticatedTemplate>
        <h2>Sign-in to see content</h2>
      </UnauthenticatedTemplate>
      <AuthenticatedTemplate>
        <Outlet />
      </AuthenticatedTemplate>
    </>
  );
};
