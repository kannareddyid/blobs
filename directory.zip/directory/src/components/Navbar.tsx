import React from "react";
import { useIsAuthenticated, useMsal } from "@azure/msal-react";
import { Link } from "react-router-dom";

export const Navbar: React.FC = () => {
  const { instance, accounts } = useMsal();

  const isAuthenticated = useIsAuthenticated();

  const userEmail = isAuthenticated ? accounts[0].username : "";

  const handleLogout = () => {
    instance.logoutRedirect();
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        {import.meta.env.VITE_APP_TITLE}_{import.meta.env.VITE_ENV}
      </div>
      <div className="navbar-links">
        <Link to="/page1">Page1</Link>
        <Link to="/page2">Page2</Link>
        <Link to="/page3">Page3</Link>
      </div>
      <div className="navbar-user">
        {isAuthenticated && (
          <div>
            {userEmail}
            <button className="signout-button" onClick={handleLogout}>
              Sign Out
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};
