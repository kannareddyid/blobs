import { Link } from "react-router-dom";

export const PageNotFound = () => {
  return (
    <>
      <h1>404 Not Found</h1>

      <div>
        <Link to="/">Home from Link</Link>
      </div>
    </>
  );
};
