import React from "react";
import { useLoginTokens } from "../hooks/useLoginTokens";

export const Page1: React.FC = () => {
  const { accessToken, idToken, error } = useLoginTokens();

  return (
    <div>
      {error && <p>Error: {error}</p>}
      <div>
        <h2>Tokens</h2>
        <p>
          <strong>Access Token:</strong>{" "}
          {accessToken ? accessToken : "Not acquired"}
        </p>
        <p>
          <strong>ID Token:</strong> {idToken ? idToken : "Not acquired"}
        </p>
      </div>
    </div>
  );
};
