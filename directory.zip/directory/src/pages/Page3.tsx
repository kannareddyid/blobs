import React, { useEffect, useState } from "react";
import { graphApiConfig } from "../configs/graphApiConfig";
import { graphApiAxiosInstance } from "../interceptors/graphApiAxiosInstance";

interface GraphData {
  id?: string;
  userPrincipalName?: string;
  displayName?: string;
}

export const Page3: React.FC = () => {
  const [graphData, setGraphData] = useState<GraphData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await graphApiAxiosInstance.get<GraphData>(
          graphApiConfig.graphApiMeEndpoint
        );
        setGraphData(response.data);
      } catch (err) {
        setError("Error fetching data");
      }
    };

    fetchData();
  }, []);

  return (
    <>
      <div>{error && <p>Error: {error}</p>}</div>
      <p>{graphData?.id}</p>
      <p>{graphData?.userPrincipalName}</p>
      <p>{graphData?.displayName}</p>
    </>
  );
};
