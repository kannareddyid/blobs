import React, { useEffect } from "react";
import { myportalApiAxiosInstance } from "../interceptors/myportalApiAxiosInstance";
import { myportalApiConfig } from "../configs/myportalApiConfig";

export const Page2: React.FC = () => {
  const [roles, setRoles] = React.useState<string[]>([]);
  const [error, setError] = React.useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await myportalApiAxiosInstance.get<string[]>(
          myportalApiConfig.getMyRolesEndpoint
        );
        setRoles(response.data);
      } catch (err) {
        setError("Error fetching data");
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      {error && <p>Error: {error}</p>}

      {roles.length > 0 ? (
        <ul>
          {roles.map((role, index) => (
            <li key={index}>{role}</li>
          ))}
        </ul>
      ) : (
        <p>Loading roles...</p>
      )}
    </div>
  );
};
