# README

## MSAL ClientSide Authentication 
- Each API with their unique AzureAppRegistration profile needs a `SilentRequest/SsoSilentRequest` authentication accessToken 
- To access any API resources, use `SilentRequest/SsoSilentRequest` authentication with respective API Scopes
- For user login use `loginRedirect` `loginPopup` => `RedirectRequest` or `PopupRequest`
- This `SsoSilentRequest` may not work in safari browser
- Understand difference between `SilentRequest & SsoSilentRequest`
- SilentRequest is used for silent token acquisition, which means obtaining tokens without any user interaction. This is commonly used for scenarios where the application needs to refresh tokens or acquire new tokens for accessing resources.
- Refer [Full React MSAL Auth Demo](https://www.youtube.com/watch?v=7oPSL5wWeS0&ab_channel=MicrosoftCommunityLearning)
- Refer ythis link [Github Reference for MSAL Scopes](https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/resources-and-scopes.md#working-with-multiple-resources)

## MSAL Scopes Validation & Functionality 
- https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/resources-and-scopes.md#working-with-multiple-resources

## Keypoints
- In Postman you have to use `resource` extraQueryParameters 
- In React+Typescript MSAL just use scope, no `resource` extraQueryParameters required

## Credentials 
- https://login.microsoftonline.com/src.xyz/oauth2/authorize
- https://login.microsoftonline.com/src.xyz/oauth2/v2.0/token
- api://f9326158-59d4-468c-8e92-5ae67058d7b5/access_as_user
- https://oauth.pstmn.io/v1/callback
- http://localhost:5173

## Libraries 
- Not used
```
npm install react-oauth2-code-flow
npm install react-oauth2-auth-code-pkce
npm install react-oidc-context
```

## MSAL
- https://learn.microsoft.com/en-us/entra/msal/dotnet/how-to/migrate-public-client?tabs=interactive

## ToolReferences
- https://jwt.io/

## YouTube References
- https://www.youtube.com/watch?v=7oPSL5wWeS0

## Repo References
- https://github.com/AzureAD/microsoft-authentication-library-for-js/tree/dev/samples

## Sanbox References
- https://codesandbox.io/p/sandbox/magical-bhabha-x454dq