package main

import (
	"net/http"
	authazure "yapi/authAzure"
)

func main() {
	config := &authazure.AzureADConfig{
		TenantID: "",
		ClientID: "",
	}

	// Open endpoint (no auth)
	http.Handle("/open", http.HandlerFunc(openHandler))

	// Secure endpoint for roles only
	http.Handle("/secure-app", config.AuthMiddlewareWithRolesAndScopes([]string{"org-yapi-role-apponly"}, nil, http.HandlerFunc(secureAppRoleHandler)))

	// Secure endpoint for roles only
	http.Handle("/secure-user", config.AuthMiddlewareWithRolesAndScopes([]string{"org-yapi-role-useronly"}, nil, http.HandlerFunc(secureUserRoleHandler)))

	// Secure endpoint for scopes only
	http.Handle("/secure-scope", config.AuthMiddlewareWithRolesAndScopes(nil, []string{"access_as_user"}, http.HandlerFunc(secureUserScopeHandler)))

	// Secure endpoint for both roles and scopes
	http.Handle("/secure-combined", config.AuthMiddlewareWithRolesAndScopes([]string{"org-yapi-role-useronly"}, []string{"access_as_user"}, http.HandlerFunc(secureCombinedHandler)))

	http.ListenAndServe(":8080", nil)
}

func openHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Open content"))
}

// App access will have & use only one(1) default scope in Client Credential Grant Flow `api://guid/.default`
// App2App access can only be protected by Roles, refered as app roles
// App can not be protected with scope, since it has only 1 scope
// App JWT token will not have scope, but will have `aud`
func secureAppRoleHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Secure content for App role"))
}

func secureUserRoleHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Secure content for User role"))
}

func secureUserScopeHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Secure content for User scope"))
}

func secureCombinedHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Secure content for User role and scope"))
}
