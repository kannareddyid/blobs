package authazure

import (
	"crypto/rsa"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"

	"github.com/golang-jwt/jwt/v5"
)

var jwksCache sync.Map // Cache for JWKS keys

// AzureADConfig holds the tenant ID and client ID for validation
type AzureADConfig struct {
	TenantID string
	ClientID string
}

// JWKS Struct for parsing keys from Azure AD
type Jwks struct {
	Keys []Jwk `json:"keys"`
}

type Jwk struct {
	Kid string   `json:"kid"`
	Kty string   `json:"kty"`
	Alg string   `json:"alg"`
	N   string   `json:"n"`
	E   string   `json:"e"`
	X5c []string `json:"x5c"`
}

// getPublicKey fetches the JWKS keys from Azure AD and returns the public key
func getPublicKey(jwksURL string, kid string) (*rsa.PublicKey, error) {
	// Check cache first
	if pubKey, found := jwksCache.Load(kid); found {
		return pubKey.(*rsa.PublicKey), nil
	}

	// Fetch the JWKS from Azure
	resp, err := http.Get(jwksURL)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch JWKS: %v", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read JWKS response: %v", err)
	}

	var jwks Jwks
	if err := json.Unmarshal(body, &jwks); err != nil {
		return nil, fmt.Errorf("failed to parse JWKS: %v", err)
	}

	// Find the key by kid
	for _, key := range jwks.Keys {
		if key.Kid == kid {
			return parseRSAKey(key)
		}
	}

	return nil, errors.New("public key not found in JWKS")
}

// parseRSAKey converts the JWK to RSA PublicKey
func parseRSAKey(jwk Jwk) (*rsa.PublicKey, error) {
	pubKey, err := jwt.ParseRSAPublicKeyFromPEM([]byte(fmt.Sprintf(`
-----BEGIN PUBLIC KEY-----
%s
-----END PUBLIC KEY-----
`, strings.Join(jwk.X5c, "\n"))))

	if err != nil {
		return nil, err
	}

	jwksCache.Store(jwk.Kid, pubKey)
	return pubKey, nil
}

// ValidateToken verifies the token and checks for roles
func (config *AzureADConfig) ValidateToken(tokenString string) (*jwt.Token, error) {
	jwksURL := fmt.Sprintf("https://login.microsoftonline.com/%s/discovery/v2.0/keys", config.TenantID)

	// Parse the JWT token and validate its signature
	return jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		// Ensure the signing method is RSA
		if _, ok := token.Method.(*jwt.SigningMethodRSA); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}

		// Extract the Key ID (kid) from the token header
		kid, ok := token.Header["kid"].(string)
		if !ok {
			return nil, fmt.Errorf("token header missing kid")
		}

		// Fetch the corresponding public key
		return getPublicKey(jwksURL, kid)
	})
}

// HasRequiredRoles checks if the user has any of the required roles
func HasRequiredRoles(userRoles []interface{}, requiredRoles []string) bool {
	roleMap := make(map[string]struct{})
	for _, role := range userRoles {
		roleMap[role.(string)] = struct{}{}
	}

	for _, requiredRole := range requiredRoles {
		if _, ok := roleMap[requiredRole]; ok {
			return true
		}
	}
	return false
}

// HasRequiredScopes checks if the user has any of the required scopes
func HasRequiredScopes(tokenScopes string, requiredScopes []string) bool {
	userScopes := strings.Split(tokenScopes, " ")
	scopeMap := make(map[string]struct{})
	for _, scope := range userScopes {
		scopeMap[scope] = struct{}{}
	}

	for _, requiredScope := range requiredScopes {
		if _, ok := scopeMap[requiredScope]; ok {
			return true
		}
	}
	return false
}

// AuthMiddlewareWithRolesAndScopes is the HTTP middleware to protect endpoints by validating tokens, roles, and scopes
func (config *AzureADConfig) AuthMiddlewareWithRolesAndScopes(requiredRoles, requiredScopes []string, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		authHeader := r.Header.Get("Authorization")
		if authHeader == "" {
			http.Error(w, "Authorization header is missing", http.StatusUnauthorized)
			return
		}

		tokenString := strings.TrimPrefix(authHeader, "Bearer ")
		token, err := config.ValidateToken(tokenString)
		if err != nil || !token.Valid {
			http.Error(w, "Invalid token", http.StatusUnauthorized)
			return
		}

		claims := token.Claims.(jwt.MapClaims)

		// Validate roles
		if len(requiredRoles) > 0 {
			roles, ok := claims["roles"].([]interface{})
			if !ok || !HasRequiredRoles(roles, requiredRoles) {
				http.Error(w, "Unauthorized - insufficient roles", http.StatusForbidden)
				return
			}
		}

		// Validate scopes
		if len(requiredScopes) > 0 {
			scopes, ok := claims["scp"].(string)
			if !ok || !HasRequiredScopes(scopes, requiredScopes) {
				http.Error(w, "Unauthorized - insufficient scopes", http.StatusForbidden)
				return
			}
		}

		next.ServeHTTP(w, r)
	})
}
